/*
 * this is the class for the object node
 */
import java.util.ArrayList;

public class Node {
	String Name;
	ArrayList<String> Given;
	String For;
	String Table;
	
	
	public Node(String FOR, ArrayList<String> given, String table) {
		super();
		Given = given;
		For = FOR;
		Table = table;
	}

	public Node(String name) {
		super();
		Name = name;
	}

	public Node(String name, String FOR, ArrayList<String> given, String table) {
		super();
		Name = name;
		Given = given;
		For = FOR;
		Table = table;
	}
	//rewrite the equal function
	public boolean equals(Object obj) {
		if (obj instanceof Node) {
			Node node = (Node) obj;
			if (node.getName() == null) {
				return false;
			} else {
				return Name.equalsIgnoreCase(node.getName());
			}
		}
		return false;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}


	public ArrayList getGiven() {
		return Given;
	}

	public void setGiven(ArrayList given) {
		Given = given;
	}

	public String getFor() {
		return For;
	}

	public void setFor(String FOR) {
		For = FOR;
	}

	public String getTable() {
		return Table;
	}

	public void setTable(String table) {
		Table = table;
	}
	
	
}
