import java.util.ArrayList;

import org.dom4j.DocumentException;

public class BNT {
	public ArrayList<Node> getAllNode(ArrayList<Node> n1, ArrayList<Node> n2) {
		
		//get all nodes from two XML
		
		ArrayList<Node> AllNode = new ArrayList<Node>();
		for (int i = 0; i < n1.size(); i++) {
//			System.out.println("Name " + n1.get(i).Name);
//			System.out.println("For " + n1.get(i).For);
//			System.out.println("Given " + n1.get(i).Given.size());
//			System.out.println("Table " + n1.get(i).Table);
//			System.out.println();
			AllNode.add(n1.get(i));
		}

		for (int i = 0; i < n2.size(); i++) {
//			System.out.println("Name " + n2.get(i).Name);
//			System.out.println("For " + n2.get(i).For);
//			System.out.println("Given " + n2.get(i).Given.size());
//			System.out.println("Table " + n2.get(i).Table);
//			System.out.println();
			if (!AllNode.contains(n2.get(i))) {
				AllNode.add(n2.get(i));
			}
		}
		// System.out.println(AllNode.size());
		return AllNode;
	}

	public ArrayList<Node> getInternal(ArrayList<Node> AllNode, ArrayList<Node> n1, ArrayList<Node> n2) {
		//get internal nodes
		
		//get the intersection of two network
		ArrayList<Node> intersection = new ArrayList<Node>();
		for (int i = 0; i < AllNode.size(); i++) {
			if (n1.contains(AllNode.get(i)) && n2.contains(AllNode.get(i))) {
				intersection.add(AllNode.get(i));
			}
		}
		// System.out.println(intersection.size());
		
		ArrayList<Node> internal = new ArrayList<Node>();
		for (int i = 0; i < intersection.size(); i++) {
			String name = intersection.get(i).Name;
			//Starting from the network 1
			for (int j = 0; j < n1.size(); j++) {
				//recognise is the node is in intersection
				if (n1.get(j).Name.equals(name)) {
					int parent = n1.get(j).Given.size();
					//in the case of no parent
					if (parent == 0) {
						internal.add(n1.get(j));
					} else {
						//in the case of having parents and recognise if the set of the parent is in intersection
						for (int p = 0; p < parent; p++) {
							Node Parent = new Node(n1.get(j).Given.get(p));
							int test = 0;
							if (intersection.contains(Parent)) {
								test++;
							}
							if (test == parent) {
								internal.add(n1.get(j));
							}
						}
					}
				}
			}
			//finding internal node in network 2
			for (int k = 0; k < n2.size(); k++) {
				if (n2.get(k).Name.equals(name)) {
					int parent = n2.get(k).Given.size();
					//in the case having no parent
					if (parent == 0 && !internal.contains(n2.get(k))) {
						internal.add(n2.get(k));
					} else {
						//in the case of having parents and recognise if the set of the parent is in intersection
						for (int p = 0; p < parent; p++) {
							Node Parent = new Node(n2.get(k).Given.get(p));
							int test = 0;
							if (intersection.contains(Parent) && !internal.contains(n2.get(k))) {
								test++;
							}
							if (test == parent) {
								internal.add(n2.get(k));
							}
						}
					}
				}
			}
		}

//		for(int i=0;i<internal.size();i++) {
//		System.out.println("internal " + internal.get(i).Name);
//	}
//	System.out.println("internal " + internal.size());
		return internal;
	}

	public ArrayList<Node> getExternal(ArrayList<Node> AllNode, ArrayList<Node> n1, ArrayList<Node> n2,
		ArrayList<Node> internal) {
		//get external nodes
			
			//get the intersection
			ArrayList<Node> intersection = new ArrayList<Node>();
			for (int i = 0; i < AllNode.size(); i++) {
				if (n1.contains(AllNode.get(i)) && n2.contains(AllNode.get(i))) {
					intersection.add(AllNode.get(i));
				}
			}
			
			//get the external namely the node is in the intersection but not in the internal
			ArrayList<Node> external = new ArrayList<Node>();
			for (int i = 0; i < intersection.size(); i++) {
				if (!internal.contains(intersection.get(i))) {
					external.add(intersection.get(i));
				}
			}
		// System.out.println(external.get(0).Name);
		return external;
		}

	public ArrayList<Node> getQ(ArrayList<Node> AllNode, ArrayList<Node> intersection) {
		//get the node in Q
		ArrayList<Node> Q = new ArrayList<Node>();
		//Q contains the node is not in the intersection
		for (int i = 0; i < AllNode.size(); i++) {
			if (!intersection.contains(AllNode.get(i))) {
				Q.add(AllNode.get(i));
			}
		}
		return Q;
	}

	public ArrayList<String[]> getDependencies(ArrayList<Node> n1, ArrayList<Node> n2) {
		//get all nodes' dependencies
		ArrayList<String[]> dependencies = new ArrayList<String[]>();
		//get the dependencies of the node in network 1
		for (int i = 0; i < n1.size(); i++) {
			if (n1.get(i).Given.size() != 0) {
				int parent_num = n1.get(i).Given.size();
				String[] dependency = new String[parent_num + 1];
				for (int j = 0; j < parent_num; j++) {
					dependency[j] = n1.get(i).Given.get(j);
				}
				dependency[dependency.length - 1] = n1.get(i).Name;
				dependencies.add(dependency);
			}
		}
		//get the dependencies of the node in network 2
		for (int i = 0; i < n2.size(); i++) {
			if (n2.get(i).Given.size() != 0) {
				int parent_num = n2.get(i).Given.size();
				String[] dependency = new String[parent_num + 1];
				for (int j = 0; j < parent_num; j++) {
					dependency[j] = n2.get(i).Given.get(j);
				}
				dependency[dependency.length - 1] = n2.get(i).Name;
				dependencies.add(dependency);
			}
		}
//		for(int i=0;i<dependencies.size();i++) {
//			for(int j=0;j<dependencies.get(i).length;j++) {
//				System.out.print(dependencies.get(i)[j] + " ");
//			}
//			System.out.println();
//		}
		return dependencies;
	}

	public ArrayList<String[]> getDependency_inter(ArrayList<Node> AllNode, ArrayList<Node> internal,
			ArrayList<Node> n1, ArrayList<Node> n2) {
		//get the dependencies of the internal node
		
		//get the intersection
		ArrayList<Node> intersection = new ArrayList<Node>();
		for (int i = 0; i < AllNode.size(); i++) {
			if (n1.contains(AllNode.get(i)) && n2.contains(AllNode.get(i))) {
				intersection.add(AllNode.get(i));
			}
		}
		
		ArrayList<String[]> dependency_inter = new ArrayList<String[]>();
		//get the dependencies of the internal node in network 1
		for (int i = 0; i < n1.size(); i++) {
			if (n1.get(i).Given.size() != 0 && internal.contains(n1.get(i))) {
				int parent_num = n1.get(i).Given.size();
				String[] dependency = new String[parent_num + 1];
				for (int j = 0; j < parent_num; j++) {
					dependency[j] = n1.get(i).Given.get(j);
				}
				dependency[dependency.length - 1] = n1.get(i).Name;
				dependency_inter.add(dependency);
			}
		}
		//get the dependencies of the internal node in network 2
		for (int i = 0; i < n2.size(); i++) {
			if (n2.get(i).Given.size() != 0 && internal.contains(n2.get(i))) {
				int parent_num = n2.get(i).Given.size();
				String[] dependency = new String[parent_num + 1];
				for (int j = 0; j < parent_num; j++) {
					dependency[j] = n2.get(i).Given.get(j);
				}
				dependency[dependency.length - 1] = n2.get(i).Name;
				dependency_inter.add(dependency);
			}
		}
//		for(int i=0;i<dependency_inter.size();i++) {
//			for(int j=0;j<dependency_inter.get(i).length;j++) {
//				System.out.print(dependency_inter.get(i)[j]+" ");
//			}
//			System.out.println();
//		}
//		System.out.println();
		
		//finding the dependencies that do not want
		ArrayList<Integer> sign = new ArrayList<Integer>();
		for (int i = 0; i < dependency_inter.size(); i++) {
			String array[] = dependency_inter.get(i);
			String s = array[array.length - 1];
			for (int j = i + 1; j < dependency_inter.size(); j++) {
				String array_searched[] = dependency_inter.get(j);
				String s_searched = array_searched[array_searched.length - 1];
				//sign the index of the repeated dependency
				if (array.length == array_searched.length && s.equals(s_searched)
						&& array[0].equals(array_searched[0])) {
					sign.add(i);
				}
				if (s.equals(s_searched)) {
					//sign the dependency that has less parent
					if (array.length > array_searched.length) {
						if (!sign.contains(j)) {
							sign.add(j);
						}
					} else if (array_searched.length > array.length) {
						sign.add(i);
					} else if (array.length == array_searched.length) {
						//sign the dependency that the parent is in the intersection
						Node n1_test = new Node(array[0]);
						Node n2_test = new Node(array_searched[0]);
						if (intersection.contains(n1_test)) {
							if (!sign.contains(i)) {
								sign.add(i);
							}
						} else if (intersection.contains(n2_test)) {
							if (!sign.contains(j)) {
								sign.add(j);
							}
						}
					}
				}
			}
		}
		//remove the signed dependencies from the list
		ArrayList<String[]> replace = new ArrayList<String[]>();
		for (int i = 0; i < dependency_inter.size(); i++) {
			if (!sign.contains(i)) {
				replace.add(dependency_inter.get(i));
			}
		}
		dependency_inter = replace;
//		for(int i=0;i<dependency_inter.size();i++) {
//			for(int j=0;j<dependency_inter.get(i).length;j++) {
//				System.out.print(dependency_inter.get(i)[j]+" ");
//			}
//			System.out.println();
//		}

		return dependency_inter;
	}

	public ArrayList<String[]> getDependency_exter(ArrayList<Node> external, ArrayList<Node> n1, ArrayList<Node> n2) {
		//get external dependencies
		ArrayList<String[]> dependency_exter = new ArrayList<String[]>();
		//get the external dependencies of external node in network 1
		for (int i = 0; i < n1.size(); i++) {
			if (n1.get(i).Given.size() != 0 && external.contains(n1.get(i))) {
				int parent_num = n1.get(i).Given.size();
				String[] dependency = new String[parent_num + 1];
				for (int j = 0; j < parent_num; j++) {
					dependency[j] = n1.get(i).Given.get(j);
				}
				dependency[dependency.length - 1] = n1.get(i).Name;
				dependency_exter.add(dependency);
			}
		}
		//get the external dependencies of external node in network 2
		for (int i = 0; i < n2.size(); i++) {
			if (n2.get(i).Given.size() != 0 && external.contains(n2.get(i))) {
				int parent_num = n2.get(i).Given.size();
				String[] dependency = new String[parent_num + 1];
				for (int j = 0; j < parent_num; j++) {
					dependency[j] = n2.get(i).Given.get(j);
				}
				dependency[dependency.length - 1] = n2.get(i).Name;
				dependency_exter.add(dependency);
			}
		}
		// System.out.println();

		return dependency_exter;
	}

	public ArrayList<Node> getCombine_external(ArrayList<Node> n1, ArrayList<Node> n2, ArrayList<Node> external) {
		//get the combination of the external node's parents
		ArrayList<Node> Combine_external = new ArrayList<Node>();
		//get the external node's data from the network 1
		for (int i = 0; i < n1.size(); i++) {
			for (int j = 0; j < external.size(); j++) {
				if (n1.get(i).equals(external.get(j))) {
					Node n = n1.get(i);
					Combine_external.add(n);
				}
			}
		}
		//get the external node's data from the network 2
		for (int i = 0; i < n2.size(); i++) {
			for (int j = 0; j < external.size(); j++) {
				if (n2.get(i).equals(external.get(j))) {
					Node n = n2.get(i);
					Combine_external.add(n);
				}
			}
		}
		
//		for(int i=0;i<Combine_external.size();i++) {
//			System.out.print("Name: " + Combine_external.get(i).Name);
//			System.out.print("  For: " + Combine_external.get(i).For);
//			for(int j=0;j<Combine_external.get(i).Given.size();j++) {
//				System.out.print("  Given: " + Combine_external.get(i).Given.get(j));
//			}
//			System.out.print("  Table: " + Combine_external.get(i).Table);
//			System.out.println();
//		}
		return Combine_external;
	}

	public ArrayList<String[]> getCPT(ArrayList<Node> n1, ArrayList<Node> n2, ArrayList<Node> external,
			ArrayList<Node> Combine_external) {
		//get the table of the external node's parents
		ArrayList<String[]> table_value = new ArrayList<String[]>();
		for (int i = 0; i < Combine_external.size(); i++) {
			String[] table = new String[Combine_external.get(i).Table.split(" ").length];
			table = Combine_external.get(i).Table.split(" ");
			table_value.add(table);
		}
		return table_value;
	}

	public static void main(String[] args) throws DocumentException {
		Reader r = new Reader();
//		ArrayList<Node> n1 = r.ReadXML("example1.xml");
//		ArrayList<Node> n2 = r.ReadXML("example2.xml");
		ArrayList<Node> n1 = r.ReadXML(args[0]);
		ArrayList<Node> n2 = r.ReadXML(args[1]);
		BNT b = new BNT();
		ArrayList<Node> AllNode = b.getAllNode(n1, n2);
		ArrayList<Node> internal = b.getInternal(AllNode, n1, n2);
		System.out.println("Internal nodes: " + internal.size());
		for(int i=0;i<internal.size();i++) {
			System.out.print(internal.get(i).Name + ", ");
		}
		System.out.println();
		System.out.println("------------------------------------------------");
		
		ArrayList<Node> external = b.getExternal(AllNode, n1, n2, internal);
		System.out.println("External nodes: " + external.size());
		for(int i=0;i<external.size();i++) {
			System.out.print(external.get(i).Name + ", ");
		}
		System.out.println();
		System.out.println("------------------------------------------------");
		ArrayList<String[]> dependencies = b.getDependencies(n1, n2);
		ArrayList<String[]> dependency_inter = b.getDependency_inter(AllNode, internal, n1, n2);
		System.out.println("Dependencies in internal nodes: " + dependency_inter.size());
		for(int i=0;i<dependency_inter.size();i++) {
			for(int j=0;j<dependency_inter.get(i).length;j++) {
				System.out.print(dependency_inter.get(i)[j] + " ");
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------");
		ArrayList<String[]> dependency_exter = b.getDependency_exter(external, n1, n2);
		
		ArrayList<Node> Combine_external = b.getCombine_external(n1, n2, external);
		ArrayList<String[]> table_value = b.getCPT(n1, n2, external, Combine_external);
		System.out.println("Dependencies in external nodes: " + dependency_exter.size());
		for(int i=0;i<dependency_exter.size();i++) {
			for(int j=0;j<dependency_exter.get(i).length;j++) {
				System.out.print(dependency_exter.get(i)[j] + " ");
			}
			System.out.println();
		}
		System.out.println("------------------------------------------------");
		double[] new_table = new double[(int) Math.pow(2, Combine_external.size() + 1)];
		new_table[0] = Double.parseDouble(table_value.get(0)[0]) + Double.parseDouble(table_value.get(1)[0])
				- Double.parseDouble(table_value.get(0)[0]) * Double.parseDouble(table_value.get(1)[0]);
		new_table[1] = Double.parseDouble(table_value.get(0)[1]) + Double.parseDouble(table_value.get(1)[1])
				- Double.parseDouble(table_value.get(0)[1]) * Double.parseDouble(table_value.get(1)[1]);
		new_table[2] = Double.parseDouble(table_value.get(0)[0]) + Double.parseDouble(table_value.get(1)[2])
				- Double.parseDouble(table_value.get(0)[0]) * Double.parseDouble(table_value.get(1)[2]);
		new_table[3] = Double.parseDouble(table_value.get(0)[1]) + Double.parseDouble(table_value.get(1)[3])
				- Double.parseDouble(table_value.get(0)[1]) * Double.parseDouble(table_value.get(1)[3]);
		new_table[4] = Double.parseDouble(table_value.get(0)[2]) + Double.parseDouble(table_value.get(1)[0])
				- Double.parseDouble(table_value.get(0)[2]) * Double.parseDouble(table_value.get(1)[0]);
		new_table[5] = Double.parseDouble(table_value.get(0)[3]) + Double.parseDouble(table_value.get(1)[1])
				- Double.parseDouble(table_value.get(0)[3]) * Double.parseDouble(table_value.get(1)[1]);
		new_table[6] = Double.parseDouble(table_value.get(0)[2]) + Double.parseDouble(table_value.get(1)[2])
				- Double.parseDouble(table_value.get(0)[2]) * Double.parseDouble(table_value.get(1)[2]);
		new_table[7] = Double.parseDouble(table_value.get(0)[3]) + Double.parseDouble(table_value.get(1)[3])
				- Double.parseDouble(table_value.get(0)[3]) * Double.parseDouble(table_value.get(1)[3]);
		System.out.println("New table for external node");
		for(int i=0;i<new_table.length;i++) {
			System.out.print(new_table[i] + ", ");
		}
		System.out.println();
		System.out.println("------------------------------------------------");
		int start = 0;
		while(start!=new_table.length) {
			double t,f;
			t = new_table[start]/(new_table[start] + new_table[start+1]);
			f = new_table[start + 1]/(new_table[start] + new_table[start+1]);
			new_table[start] = t;
			new_table[start+1] = f;
			start+=2;
		}
		System.out.println("Normalize");
		for(int i=0;i<new_table.length;i++) {
			System.out.print(new_table[i] + ", ");
		}
	}
}
