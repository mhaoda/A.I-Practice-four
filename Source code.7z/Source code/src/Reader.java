/*
 * this is the class for reading the content of the XML file
 */
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class Reader {
	public ArrayList<Node> ReadXML(String s) throws DocumentException {
		SAXReader reader = new SAXReader();//initialize the SAXReader tool
		Document document = reader.read(new File(s));//read the data in the XML file
		Element node = document.getRootElement();//get the root node of the network
		Element Network = node.element("NETWORK");//get the deeper node by the root node
		ArrayList<Node> n1 = new ArrayList<Node>();
		//Finding the tag ��VARIABLE�� and creating the node object using the value in ��NAME�� tag
		Iterator<Element> tt = Network.elementIterator();//Iterate the node in "NETWORK"
		while (tt.hasNext()) {
			Element e = tt.next();
			if (e.getName().equals("VARIABLE")) {
				Iterator<Element> itt = e.elementIterator();
				while (itt.hasNext()) {
					Element ee = itt.next();
					if (ee.getName().equals("NAME")) {
						Node n = new Node(ee.getText());
						n1.add(n);
					}
				}
			}
		}
		Iterator<Element> it = Network.elementIterator();
		int count = 0;
		while (it.hasNext()) {
			Element e = it.next();
			if (e.getName().equals("DEFINITION")) {
				Iterator<Element> itt = e.elementIterator();
				String For = null, Table = null;
				ArrayList<String> Given = new ArrayList<String>();
				while (itt.hasNext()) {
					
					Element ee = itt.next();
					if (ee.getName().equals("FOR")) {
						//System.out.println("FOR " + ee.getText());
						For = ee.getText();
					}
					if (ee.getName().equals("GIVEN")) {
						//System.out.println("GIVEN " + ee.getText());
						Given.add(ee.getText());
					}
					if (ee.getName().equals("TABLE")) {
						//System.out.println("TABLE " + ee.getText());
						Table = ee.getText();
					}
				}
				//System.out.println("For " + For);
				if(Given.size()==0) {
					//System.out.println("Given " + "null");
				}else {
					for(int i=0;i<Given.size();i++) {
						//System.out.println("Given " + Given.get(i));
					}
				}
				//System.out.println("Table " + Table);
				//System.out.println(count);
				n1.get(count).setFor(For);
				n1.get(count).setGiven(Given);
				n1.get(count).setTable(Table);
				//System.out.println(n1.get(count).Name);
				count++;
				//System.out.println();
			}
		}
		return n1;
	}
}
